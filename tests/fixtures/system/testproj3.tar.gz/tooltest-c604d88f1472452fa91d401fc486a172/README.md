Hello Anaconda Enterprise!

A simple anaconda-project example that only depends on python.
Mostly created to demonstrate that sample projects and deployments are running
on even the simplest installation of anaconda-enterprise. Other examples in the 
sample projects will better demonstrate how to get up and running with anaconda-projects.

To run this example from the directory:

```
anaconda-project run
```
