#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time

for x in range(3):
    print("Hello Anaconda Enterprise!")
    time.sleep(5)
